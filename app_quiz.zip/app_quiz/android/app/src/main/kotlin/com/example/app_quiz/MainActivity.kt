package com.example.app_quiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
